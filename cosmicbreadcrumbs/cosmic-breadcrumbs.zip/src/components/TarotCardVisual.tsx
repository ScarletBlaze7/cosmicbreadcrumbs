import React, { useState } from 'react';
import { Sparkles, Maximize2, RotateCw } from 'lucide-react';
import { TarotCard, DrawnCard } from '../types';
import { getRwsCardImageUrl, getRwsBackupImageUrl } from '../utils/tarotImageHelper';

interface TarotCardVisualProps {
  card: TarotCard | DrawnCard;
  isReversed?: boolean;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'hero';
  className?: string;
  showReversedBanner?: boolean;
  allowZoom?: boolean;
  onCardClick?: () => void;
  priority?: boolean;
}

export const TarotCardVisual: React.FC<TarotCardVisualProps> = ({
  card,
  isReversed = false,
  size = 'md',
  className = '',
  showReversedBanner = true,
  allowZoom = false,
  onCardClick,
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [triedBackup, setTriedBackup] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);

  // Check if reversed from prop or from DrawnCard object
  const reversed = isReversed || (('isReversed' in card) && Boolean((card as DrawnCard).isReversed));

  const primaryUrl = getRwsCardImageUrl(card);
  const backupUrl = getRwsBackupImageUrl(card);
  const currentSrc = triedBackup ? backupUrl : primaryUrl;

  const handleImageError = () => {
    if (!triedBackup) {
      setTriedBackup(true);
    } else {
      setHasError(true);
    }
  };

  // Size dimensions (traditional Tarot aspect ratio approx 1 : 1.72)
  const sizeClasses = {
    xs: 'w-14 h-24 text-[9px]',
    sm: 'w-24 h-40 text-[10px]',
    md: 'w-36 h-60 text-xs',
    lg: 'w-48 h-80 text-sm',
    xl: 'w-56 h-96 text-sm',
    hero: 'w-44 sm:w-60 md:w-68 h-72 sm:h-96 md:h-[27rem] text-sm',
  };

  return (
    <>
      <div
        onClick={() => {
          if (allowZoom) {
            setIsZoomed(true);
          } else if (onCardClick) {
            onCardClick();
          }
        }}
        className={`group relative flex flex-col items-center justify-center select-none ${sizeClasses[size]} ${
          allowZoom || onCardClick ? 'cursor-pointer' : ''
        } ${className}`}
      >
        {/* Card Frame & Outer Glow */}
        <div
          className={`relative h-full w-full overflow-hidden rounded-2xl border-2 border-amber-400/40 bg-slate-950 shadow-xl transition-all duration-500 ease-out group-hover:border-amber-300 group-hover:shadow-2xl group-hover:shadow-amber-500/20 ${
            reversed ? 'ring-1 ring-purple-500/40' : 'ring-1 ring-amber-400/20'
          }`}
        >
          {/* Card Artwork Image Container */}
          <div
            className={`relative h-full w-full transition-transform duration-700 ease-in-out ${
              reversed ? 'rotate-180' : 'rotate-0'
            }`}
          >
            {!hasError ? (
              <>
                {/* Vintage Card Image */}
                <img
                  src={currentSrc}
                  alt={`${card.name} - Authentic 1909 Rider-Waite-Smith Tarot Card`}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  onLoad={() => setImageLoaded(true)}
                  onError={handleImageError}
                  className={`h-full w-full object-cover object-center transition-opacity duration-500 ${
                    imageLoaded ? 'opacity-100' : 'opacity-0'
                  }`}
                />

                {/* Loading Skeleton / Placeholder */}
                {!imageLoaded && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-purple-950/80 to-slate-900 p-2 text-center">
                    <Sparkles className="h-6 w-6 text-amber-400/70 animate-pulse mb-1.5" />
                    <span className="text-[10px] font-medium text-purple-300/80 line-clamp-1">
                      {card.name}
                    </span>
                    <span className="text-[9px] text-amber-400/60 font-mono mt-0.5">1909 RWS</span>
                  </div>
                )}
              </>
            ) : (
              /* Fallback Archetype View if Network is Blocked */
              <div className="flex h-full w-full flex-col items-center justify-between bg-gradient-to-b from-slate-900 via-purple-950 to-slate-950 p-3 text-center">
                <div className="w-full flex justify-between items-center text-[10px] text-amber-400/80 border-b border-purple-800/40 pb-1">
                  <span>{card.arcana}</span>
                  <span>{card.suit.toUpperCase()}</span>
                </div>
                <div className="my-auto flex flex-col items-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-500/10 border border-amber-400/30 text-amber-300">
                    <Sparkles className="h-7 w-7 text-amber-400" />
                  </div>
                  <span className="mt-2 text-xs font-serif font-bold text-slate-100 line-clamp-2 px-1">
                    {card.name}
                  </span>
                </div>
                <div className="w-full text-[9px] text-purple-300/70 border-t border-purple-800/40 pt-1">
                  Original 1909 Deck
                </div>
              </div>
            )}

            {/* Subtle vintage texture overlay */}
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-black/10 mix-blend-multiply" />
          </div>

          {/* Authentic 1909 Badge */}
          <div className="absolute top-1.5 left-1.5 z-10 pointer-events-none">
            <span className="rounded-md bg-slate-950/80 px-1.5 py-0.5 text-[8px] font-bold text-amber-300/90 border border-amber-400/30 backdrop-blur-xs">
              1909 RWS
            </span>
          </div>

          {/* Quick Zoom Action Button */}
          {allowZoom && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsZoomed(true);
              }}
              title="Inspect Original 1909 Artwork"
              className="absolute top-1.5 right-1.5 z-10 rounded-md bg-slate-950/80 p-1 text-purple-300 hover:text-amber-300 border border-purple-800/60 opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-xs"
            >
              <Maximize2 className="h-3 w-3" />
            </button>
          )}

          {/* Reversed Indicator Badge */}
          {reversed && showReversedBanner && (
            <div className="absolute bottom-1.5 inset-x-1.5 z-10 flex items-center justify-center rounded-lg bg-purple-950/90 py-0.5 text-[9px] font-bold text-purple-200 border border-purple-600/60 shadow-md backdrop-blur-xs">
              <RotateCw className="h-2.5 w-2.5 mr-1 text-amber-400" />
              <span>REVERSED</span>
            </div>
          )}
        </div>
      </div>

      {/* Lightbox / Zoom Modal for High-Res 1909 Scan */}
      {isZoomed && (
        <div
          onClick={() => setIsZoomed(false)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-sm w-full overflow-hidden rounded-3xl border border-amber-400/40 bg-slate-950 p-4 shadow-2xl space-y-3"
          >
            <div className="flex items-center justify-between border-b border-purple-900/60 pb-2">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                  Authentic 1909 Pamela Colman Smith Scan
                </span>
                <h4 className="font-serif text-base font-bold text-slate-100">{card.name}</h4>
              </div>
              <button
                onClick={() => setIsZoomed(false)}
                className="rounded-full bg-purple-900/40 p-1.5 text-purple-300 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="relative flex items-center justify-center overflow-hidden rounded-2xl bg-black/60 p-2">
              <img
                src={currentSrc}
                alt={`${card.name} 1909 original`}
                referrerPolicy="no-referrer"
                className={`max-h-[60vh] w-auto object-contain rounded-lg shadow-2xl transition-transform ${
                  reversed ? 'rotate-180' : ''
                }`}
              />
            </div>

            <div className="space-y-1 rounded-xl bg-purple-950/40 p-2.5 border border-purple-900/40 text-[11px] text-purple-200/90 leading-relaxed">
              <span className="font-bold text-amber-300 block">Original 1909 First Edition:</span>
              <p className="line-clamp-3 italic">{card.pictorialKeyDescription || card.visualDescription}</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
