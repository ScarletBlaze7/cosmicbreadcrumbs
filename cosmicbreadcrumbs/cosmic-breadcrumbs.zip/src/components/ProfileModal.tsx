import React, { useState } from 'react';
import { X, Sparkles, Calendar, Clock, MapPin, User, Compass, Check, Camera, Crown, Gift, ShieldCheck } from 'lucide-react';
import { UserProfile, MembershipStatus } from '../types';
import { getSunSignFromDate } from '../utils/astrologyCalc';
import { calculateLifePath, calculateDestinyNumber } from '../utils/numerologyCalc';
import { CosmicLogo } from './CosmicLogo';
import { ZodiacSymbolIcon } from './ZodiacSymbolIcon';
import { getTrialTimeRemaining } from '../utils/membership';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onSaveProfile: (profile: UserProfile) => void;
  membership?: MembershipStatus;
  onOpenMembership?: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onSaveProfile,
  membership,
  onOpenMembership,
}) => {
  const [formData, setFormData] = useState<UserProfile>({ ...userProfile });
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const trialTime = getTrialTimeRemaining(membership?.trialExpiryDate);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const sunSign = getSunSignFromDate(formData.birthDate).name;
    const lifePathNumber = calculateLifePath(formData.birthDate);
    const destinyNumber = calculateDestinyNumber(formData.name);

    const updated: UserProfile = {
      ...formData,
      sunSign,
      lifePathNumber,
      destinyNumber,
    };

    onSaveProfile(updated);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 900);
  };

  const previewSunSign = getSunSignFromDate(formData.birthDate || '1995-07-15');
  const previewLifePath = calculateLifePath(formData.birthDate || '1995-07-15');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-purple-900/60 bg-slate-900 shadow-2xl shadow-purple-950/50 animate-in fade-in zoom-in-95 duration-200">
        {/* Glow Header */}
        <div className="relative border-b border-purple-800/40 bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <CosmicLogo size="md" showUploadTrigger={true} />
              <div>
                <h3 className="font-serif text-lg font-bold text-slate-100">
                  Your Cosmic Birth Matrix
                </h3>
                <p className="text-xs text-purple-300/80">
                  Cosmic Breadcrumbs • Personalize your Universal insights
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="rounded-full p-1.5 text-slate-400 hover:bg-purple-900/40 hover:text-slate-100 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Quick Matrix Banner */}
          <div className="mt-4 flex items-center justify-around rounded-xl border border-purple-800/30 bg-slate-950/60 p-2.5 text-center">
            <div>
              <span className="text-[10px] uppercase tracking-wider text-purple-400">Sun Sign</span>
              <p className="text-sm font-semibold text-amber-300 flex items-center justify-center space-x-1.5 mt-0.5">
                <ZodiacSymbolIcon sign={previewSunSign.name} size="sm" fallbackText={previewSunSign.symbol} />
                <span>{previewSunSign.name}</span>
              </p>
            </div>
            <div className="h-8 w-px bg-purple-900/50" />
            <div>
              <span className="text-[10px] uppercase tracking-wider text-purple-400">Life Path</span>
              <p className="text-sm font-semibold text-purple-200">
                Number {previewLifePath}
              </p>
            </div>
            <div className="h-8 w-px bg-purple-900/50" />
            <div>
              <span className="text-[10px] uppercase tracking-wider text-purple-400">Element</span>
              <p className="text-sm font-semibold text-cyan-300">
                {previewSunSign.element}
              </p>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* Full Name */}
          <div>
            <label className="block text-xs font-medium text-purple-200 mb-1.5 flex items-center space-x-1.5">
              <User className="h-3.5 w-3.5 text-purple-400" />
              <span>Full Birth Name (for Destiny & Soul Urge Numbers)</span>
            </label>
            <input
              type="text"
              required
              id="input-profile-name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. Tiffany Carver"
              className="w-full rounded-xl border border-purple-900/60 bg-slate-950/80 px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-600 focus:border-amber-400 focus:outline-none focus:ring-1 focus:ring-amber-400/50 transition-all"
            />
          </div>

          {/* Birth Date */}
          <div>
            <label className="block text-xs font-medium text-purple-200 mb-1.5 flex items-center space-x-1.5">
              <Calendar className="h-3.5 w-3.5 text-purple-400" />
              <span>Date of Birth</span>
            </label>
            <input
              type="date"
              required
              id="input-profile-birthdate"
              value={formData.birthDate}
              onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
              className="w-full rounded-xl border border-purple-900/60 bg-slate-950/80 px-3.5 py-2.5 text-sm text-slate-100 focus:border-amber-400 focus:outline-none focus:ring-1 focus:ring-amber-400/50 transition-all"
            />
          </div>

          {/* Time & Place Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-purple-200 mb-1.5 flex items-center space-x-1.5">
                <Clock className="h-3.5 w-3.5 text-purple-400" />
                <span>Exact Birth Time (Optional)</span>
              </label>
              <input
                type="time"
                id="input-profile-birthtime"
                value={formData.birthTime || ''}
                onChange={(e) => setFormData({ ...formData, birthTime: e.target.value })}
                className="w-full rounded-xl border border-purple-900/60 bg-slate-950/80 px-3 py-2 text-sm text-slate-100 focus:border-amber-400 focus:outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-purple-200 mb-1.5 flex items-center space-x-1.5">
                <MapPin className="h-3.5 w-3.5 text-purple-400" />
                <span>Birth City / Location</span>
              </label>
              <input
                type="text"
                id="input-profile-birthplace"
                value={formData.birthPlace || ''}
                onChange={(e) => setFormData({ ...formData, birthPlace: e.target.value })}
                placeholder="e.g. Austin, Texas"
                className="w-full rounded-xl border border-purple-900/60 bg-slate-950/80 px-3 py-2 text-sm text-slate-100 placeholder-slate-600 focus:border-amber-400 focus:outline-none transition-all"
              />
            </div>
          </div>

          {/* Numerology System */}
          <div>
            <label className="block text-xs font-medium text-purple-200 mb-1.5 flex items-center space-x-1.5">
              <Compass className="h-3.5 w-3.5 text-amber-400" />
              <span>Sacred Numerology System</span>
            </label>
            <div className="rounded-xl border border-amber-400/50 bg-gradient-to-r from-amber-950/40 via-purple-950/40 to-slate-950 p-3.5 flex items-start space-x-3 shadow-inner">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-amber-500/20 text-amber-300 font-serif text-sm font-bold border border-amber-400/40">
                ✦
              </div>
              <div className="space-y-0.5">
                <div className="font-semibold text-xs text-amber-300 flex items-center space-x-1.5">
                  <span>Chaldean Sacred Vibration System</span>
                  <span className="rounded-full bg-amber-400/20 text-amber-300 text-[9px] px-1.5 py-0.2 border border-amber-400/30">Active</span>
                </div>
                <p className="text-[11px] text-purple-200/80 leading-relaxed">
                  Ancient Babylonian occult sound vibration system (Digits 1–8 & Sacred Divine 9) with Master Numbers (11, 22, 33).
                </p>
              </div>
            </div>
          </div>

          {/* Membership Tier & Status Section */}
          {membership && (
            <div className="rounded-2xl border border-purple-800/40 bg-slate-950/60 p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {membership.tier === 'trial' ? (
                    <Gift className="h-4 w-4 text-amber-400" />
                  ) : membership.isActive ? (
                    <Crown className="h-4 w-4 text-amber-400" />
                  ) : (
                    <Sparkles className="h-4 w-4 text-purple-400" />
                  )}
                  <span className="font-serif text-xs font-bold text-slate-200">
                    Sanctuary Membership
                  </span>
                </div>
                <span className="rounded-full bg-amber-500/20 border border-amber-500/30 px-2 py-0.5 text-[10px] font-bold text-amber-300">
                  {membership.tier === 'trial' && membership.isActive
                    ? `Trial (${trialTime.days}d ${trialTime.hours}h)`
                    : membership.isActive
                    ? (membership.planName || 'Active Member')
                    : 'Free App Tier'}
                </span>
              </div>

              <p className="text-[11px] text-purple-300/80 leading-relaxed">
                {membership.isActive 
                  ? 'All features unlocked: Horoscopes, Numerology, Angel Codes, Tarot, Dream Sanctuary, and Lockable Diary.'
                  : 'Free tier includes Daily Horoscope and Daily Tarot Card Pull. Activate your free 3-day trial or subscribe for complete use.'}
              </p>

              {onOpenMembership && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenMembership();
                  }}
                  className="w-full rounded-xl border border-amber-500/40 bg-amber-500/10 py-2 text-xs font-semibold text-amber-200 hover:bg-amber-500/20 transition-all text-center"
                >
                  {membership.isActive ? 'Manage Membership / Switch Plans ($3, $11, $33)' : 'Claim Free 3-Day Trial or View Subscriptions ($3, $11, $33)'}
                </button>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="pt-3 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-purple-900/60 px-4 py-2.5 text-xs font-medium text-slate-300 hover:bg-purple-950/40 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="btn-save-profile"
              className="flex items-center space-x-2 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 px-5 py-2.5 text-xs font-semibold text-white shadow-lg shadow-purple-600/30 hover:opacity-95 transition-opacity"
            >
              {savedSuccess ? (
                <>
                  <Check className="h-4 w-4 text-white" />
                  <span>Aligned & Saved!</span>
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 text-amber-300" />
                  <span>Save Cosmic Alignment</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
