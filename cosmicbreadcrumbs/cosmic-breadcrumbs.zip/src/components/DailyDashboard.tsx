import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Moon, 
  Compass, 
  Hash, 
  Feather, 
  ArrowRight, 
  Heart, 
  RotateCw, 
  Share2, 
  CheckCircle2,
  Lock,
  CloudMoon,
  Gift,
  Crown,
  Sun,
  Shield,
  BookOpen,
  Calendar,
  Check,
  Radio,
  Activity
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { UserProfile, CosmicView, TarotCard, DrawnCard, MembershipStatus } from '../types';
import { getSunSignFromDate, getMoonPhaseInfo, getDailyPlanetaryTransits } from '../utils/astrologyCalc';
import { calculateLifePath, calculatePersonalYear, calculateDestinyNumber } from '../utils/numerologyCalc';
import { ALL_TAROT_CARDS } from '../data/tarotData';
import { getDailyArchangelCard } from '../data/angelData';
import { CosmicLogo } from './CosmicLogo';
import { CosmicTitleVideo } from './CosmicTitleVideo';
import { NasaAstrologyRadar } from './NasaAstrologyRadar';
import { ZodiacSymbolIcon } from './ZodiacSymbolIcon';
import { TarotCardVisual } from './TarotCardVisual';
import { getTrialTimeRemaining, isFeatureUnlocked } from '../utils/membership';
import { getStoredDailyTarot, saveDailyPrimaryCard, getTimeUntilMidnight } from '../utils/dailyTarotStorage';

interface DailyDashboardProps {
  userProfile: UserProfile;
  onNavigate: (view: CosmicView) => void;
  onSaveJournal: (title: string, type: 'tarot' | 'horoscope' | 'angel' | 'numerology', content: string) => void;
  membership: MembershipStatus;
  onOpenWelcomeModal: (featureName?: string, tab?: 'letter' | 'plans' | 'guide') => void;
}

const MONTHS = [
  { value: '01', name: 'January' },
  { value: '02', name: 'February' },
  { value: '03', name: 'March' },
  { value: '04', name: 'April' },
  { value: '05', name: 'May' },
  { value: '06', name: 'June' },
  { value: '07', name: 'July' },
  { value: '08', name: 'August' },
  { value: '09', name: 'September' },
  { value: '10', name: 'October' },
  { value: '11', name: 'November' },
  { value: '12', name: 'December' },
];

export const DailyDashboard: React.FC<DailyDashboardProps> = ({
  userProfile,
  onNavigate,
  onSaveJournal,
  membership,
  onOpenWelcomeModal,
}) => {
  const sunSign = getSunSignFromDate(userProfile.birthDate);
  const moonInfo = getMoonPhaseInfo();
  const transits = getDailyPlanetaryTransits();
  const lifePath = calculateLifePath(userProfile.birthDate);
  const personalYear = calculatePersonalYear(userProfile.birthDate);
  const trialTime = getTrialTimeRemaining(membership.trialExpiryDate);

  // Daily Quick Tarot Pull State (1 card per day with midnight reset)
  const [dailyRecord, setDailyRecord] = useState(() => getStoredDailyTarot());
  const dailyCard = dailyRecord?.primaryCard || null;
  const [timeToMidnight, setTimeToMidnight] = useState(() => getTimeUntilMidnight());
  const [isFlipping, setIsFlipping] = useState(false);
  const [isSavedToday, setIsSavedToday] = useState(false);

  // Interactive Zodiac Sign Calculator State
  const [calcMonth, setCalcMonth] = useState<string>('07');
  const [calcDay, setCalcDay] = useState<string>('22');
  const [calcResult, setCalcResult] = useState<{
    name: string;
    symbol: string;
    element: string;
    ruler: string;
    dates: string;
    chaldeanRoot: number;
    description: string;
  } | null>(null);

  // NASA Planetary Radar Live View State
  const [showNasaRadar, setShowNasaRadar] = useState(false);

  // Sync daily tarot updates from anywhere in the app & countdown timer
  useEffect(() => {
    const handleUpdate = () => {
      setDailyRecord(getStoredDailyTarot());
    };
    window.addEventListener('daily-tarot-updated', handleUpdate);

    const timer = setInterval(() => {
      const remaining = getTimeUntilMidnight();
      setTimeToMidnight(remaining);
      if (remaining.hours === 0 && remaining.minutes === 0 && remaining.seconds <= 1) {
        setDailyRecord(getStoredDailyTarot());
      }
    }, 1000);

    return () => {
      window.removeEventListener('daily-tarot-updated', handleUpdate);
      clearInterval(timer);
    };
  }, []);

  const dailyArchangel = getDailyArchangelCard();

  const handlePullDailyCard = () => {
    if (isFlipping || dailyCard) return;
    setIsFlipping(true);

    setTimeout(() => {
      const randomIndex = Math.floor(Math.random() * ALL_TAROT_CARDS.length);
      const picked = ALL_TAROT_CARDS[randomIndex];
      const isReversed = Math.random() > 0.75;

      const drawn: DrawnCard = {
        ...picked,
        isReversed,
        positionName: 'Daily Cosmic Breadcrumb',
        positionDescription: 'Universal guidance aligned with your celestial vibration today.',
      };

      const updatedRecord = saveDailyPrimaryCard(drawn);
      setDailyRecord(updatedRecord);
      setIsFlipping(false);

      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.65 },
        colors: ['#fbbf24', '#c084fc', '#38bdf8', '#f43f5e'],
      });
    }, 700);
  };

  const handleCalculateZodiac = (e: React.FormEvent) => {
    e.preventDefault();
    const dayNum = parseInt(calcDay, 10);
    if (isNaN(dayNum) || dayNum < 1 || dayNum > 31) return;

    const fakeIsoDate = `2000-${calcMonth}-${dayNum.toString().padStart(2, '0')}`;
    const sign = getSunSignFromDate(fakeIsoDate);

    // Chaldean vibration mapping for signs
    const signChaldeanMap: Record<string, { num: number; desc: string }> = {
      Aries: { num: 9, desc: 'Fiery Mars vibration: Pioneer, boldness, raw energetic initiation.' },
      Taurus: { num: 6, desc: 'Venusian harmonic: Material mastery, devotion, grounded beauty.' },
      Gemini: { num: 5, desc: 'Mercurial speed: Mental versatility, winged messenger, dual perception.' },
      Cancer: { num: 2, desc: 'Lunar intuition: Emotional depth, psychic shielding, sacred nurture.' },
      Leo: { num: 1, desc: 'Solar sovereignty: Pure divine spark, creative authority, radiant heart.' },
      Virgo: { num: 5, desc: 'Mercurial refinement: Sacred discernment, healing alchemy, precision.' },
      Libra: { num: 6, desc: 'Venusian balance: Cosmic equilibrium, artistic grace, soul partnership.' },
      Scorpio: { num: 9, desc: 'Martian & Plutonian depth: Phoenix rebirth, mystery, unwavering focus.' },
      Sagittarius: { num: 3, desc: 'Jupiterian expansion: Philosophical optimism, spiritual truth seeker.' },
      Capricorn: { num: 8, desc: 'Saturnian architect: Karmic mastery, endurance, mountain peak wisdom.' },
      Aquarius: { num: 4, desc: 'Uranian catalyst: Visionary frequency, revolutionary humanitarianism.' },
      Pisces: { num: 7, desc: 'Neptunian mystic: Universal oneness, transcendent empathy, dream weaver.' },
    };

    const chaldean = signChaldeanMap[sign.name] || { num: 7, desc: 'Celestial intuitive vibration.' };

    setCalcResult({
      name: sign.name,
      symbol: sign.symbol,
      element: sign.element,
      ruler: sign.rulingPlanet,
      dates: sign.dateRange,
      chaldeanRoot: chaldean.num,
      description: chaldean.desc,
    });
  };

  const handleSaveToJournal = () => {
    if (!dailyCard) return;
    const content = `☀️ Sun Sign: ${sunSign.name} (${sunSign.symbol})\n🌙 Moon Phase: ${moonInfo.phaseName} (${moonInfo.illumination}%)\n🔢 Life Path: ${lifePath} | Personal Year: ${personalYear}\n🕊️ Archangel: ${dailyArchangel.archangel} (${dailyArchangel.title})\n🃏 Daily Tarot: ${dailyCard.name} (${dailyCard.isReversed ? 'Reversed' : 'Upright'})\nMessage: ${dailyCard.isReversed ? dailyCard.reversedMeaning : dailyCard.uprightMeaning}\nAffirmation: "${dailyCard.affirmation}"`;

    onSaveJournal(`Daily Cosmic Reading - ${new Date().toLocaleDateString()}`, 'tarot', content);
    setIsSavedToday(true);
    setTimeout(() => setIsSavedToday(false), 2500);
  };

  return (
    <div className="mx-auto max-w-xl sm:max-w-2xl px-3 py-4 sm:py-6 space-y-5 animate-in fade-in duration-300 pb-20">

      {/* CENTERPIECE MAIN TITLE: EXACT ANIMATED COSMIC BREADCRUMBS VIDEO TITLE */}
      <div className="space-y-3 pt-1">
        <CosmicTitleVideo variant="hero" />
      </div>

      {/* USER ALIGNMENT SUB-BANNER */}
      <div className="relative flex flex-col items-center justify-center rounded-3xl border border-purple-900/50 bg-gradient-to-b from-purple-950/40 via-slate-950/80 to-slate-950 p-4 shadow-xl overflow-hidden">
        <div className="pointer-events-none absolute -top-12 h-32 w-32 rounded-full bg-cyan-500/10 blur-2xl" />
        
        <div className="flex items-center space-x-4">
          <div className="relative">
            <CosmicLogo size="lg" showUploadTrigger={true} />
            <div className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-amber-400 text-slate-950 text-[10px] font-bold shadow-md">
              ✨
            </div>
          </div>

          <div className="space-y-0.5 text-left">
            <div className="flex items-center space-x-1.5 text-xs font-bold text-amber-300">
              <Sparkles className="h-3.5 w-3.5" />
              <span>Universal Sanctuary Oracle</span>
            </div>
            <p className="text-xs text-slate-200 font-serif font-medium">
              Seraphina Starling • {sunSign.symbol} {sunSign.name}
            </p>
            <p className="text-[10px] text-purple-300/70">
              Chaldean Life Path {lifePath} • {moonInfo.phaseName}
            </p>
          </div>
        </div>
      </div>

      {/* CARD 1: TODAY'S FORECAST */}
      <div className="rounded-3xl border border-purple-900/50 bg-slate-950/80 p-6 sm:p-7 shadow-2xl backdrop-blur-md space-y-4 text-center">
        <div className="text-[11px] font-mono font-bold tracking-widest text-purple-400 uppercase">
          TODAY'S FORECAST
        </div>

        <h2 className="font-philosopher text-2xl sm:text-3xl font-bold tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-slate-100 via-purple-100 to-amber-100 drop-shadow-sm">
          Cosmic Alignment Active
        </h2>

        <p className="text-xs sm:text-sm text-purple-200/90 leading-relaxed max-w-lg mx-auto font-sans">
          The stars align to bring clarity to your path. Trust your inner vision and embrace upcoming opportunities today.
        </p>

        {/* Alignment Matrix Pills */}
        <div className="pt-2 flex flex-wrap items-center justify-center gap-2">
          <div className="inline-flex items-center space-x-1.5 rounded-full border border-purple-800/60 bg-purple-950/50 px-3 py-1 text-xs text-purple-200">
            <ZodiacSymbolIcon sign={sunSign.name} size="sm" fallbackText={sunSign.symbol} />
            <span>Sun in {sunSign.name}</span>
          </div>

          <div className="inline-flex items-center space-x-1.5 rounded-full border border-cyan-800/60 bg-cyan-950/40 px-3 py-1 text-xs text-cyan-200">
            <Moon className="h-3 w-3 text-cyan-400" />
            <span>{moonInfo.phaseName} ({moonInfo.illumination}%)</span>
          </div>

          <div className="inline-flex items-center space-x-1.5 rounded-full border border-amber-500/40 bg-amber-500/10 px-3 py-1 text-xs text-amber-300 font-semibold">
            <Sparkles className="h-3 w-3 text-amber-400" />
            <span>Resonance 94%</span>
          </div>
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-2.5">
          <button
            onClick={() => onNavigate('horoscope')}
            className="w-full sm:w-auto rounded-full border border-purple-700 bg-purple-950/60 px-5 py-2 text-xs font-semibold text-purple-200 hover:bg-purple-900/60 hover:text-white transition-all"
          >
            Read Full Horoscope →
          </button>

          <button
            onClick={() => setShowNasaRadar(!showNasaRadar)}
            className="w-full sm:w-auto rounded-full border border-cyan-500/40 bg-cyan-950/40 px-5 py-2 text-xs font-semibold text-cyan-300 hover:bg-cyan-900/50 hover:text-white transition-all flex items-center justify-center space-x-1.5 shadow-md"
          >
            <Radio className="h-3.5 w-3.5 text-cyan-400 animate-pulse" />
            <span>{showNasaRadar ? 'Hide NASA Telemetry' : 'NASA Planetary Radar (Live)'}</span>
          </button>
        </div>

        {/* Real-time NASA Telemetry Radar Expansion */}
        {showNasaRadar && (
          <div className="mt-4 pt-3 border-t border-purple-900/40 text-left animate-in fade-in zoom-in-95 duration-200">
            <NasaAstrologyRadar />
          </div>
        )}
      </div>

      {/* CARD 2: CALCULATOR - FIND YOUR ZODIAC SIGN */}
      <div className="rounded-3xl border border-purple-900/50 bg-slate-950/80 p-6 sm:p-7 shadow-2xl backdrop-blur-md space-y-4 text-center">
        <div className="text-[11px] font-mono font-bold tracking-widest text-purple-400 uppercase">
          CALCULATOR
        </div>

        <h3 className="font-philosopher text-2xl sm:text-3xl font-bold tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-slate-100 via-purple-100 to-amber-100 drop-shadow-sm">
          Find your Zodiac Sign
        </h3>

        <form onSubmit={handleCalculateZodiac} className="space-y-3 max-w-md mx-auto pt-1">
          <div className="grid grid-cols-2 gap-2.5">
            {/* Month Select */}
            <div className="relative">
              <select
                value={calcMonth}
                onChange={(e) => setCalcMonth(e.target.value)}
                className="w-full appearance-none rounded-2xl border border-purple-900/70 bg-slate-900 px-4 py-3 text-xs font-semibold text-slate-100 focus:border-amber-400 focus:outline-none"
              >
                {MONTHS.map((m) => (
                  <option key={m.value} value={m.value} className="bg-slate-900 text-slate-100">
                    {m.name}
                  </option>
                ))}
              </select>
              <div className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-purple-400 text-xs">
                ▼
              </div>
            </div>

            {/* Day Input */}
            <div>
              <input
                type="number"
                min="1"
                max="31"
                value={calcDay}
                onChange={(e) => setCalcDay(e.target.value)}
                placeholder="Day (1-31)"
                className="w-full rounded-2xl border border-purple-900/70 bg-slate-900 px-4 py-3 text-xs font-semibold text-slate-100 placeholder-slate-500 focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          {/* Calculate Button */}
          <button
            type="submit"
            className="w-full rounded-2xl border border-purple-600/70 bg-slate-900/90 py-3 px-6 font-mono text-xs font-bold tracking-widest text-slate-100 uppercase hover:bg-purple-950/60 hover:border-amber-400 active:scale-[0.99] transition-all shadow-md"
          >
            CALCULATE SIGN
          </button>
        </form>

        {/* Calculated Result Popover */}
        {calcResult && (
          <div className="mt-4 rounded-2xl border border-amber-500/40 bg-gradient-to-b from-purple-950/60 to-slate-900 p-4 text-left space-y-2 animate-in fade-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-950 border border-purple-800/80 p-0.5">
                  <ZodiacSymbolIcon sign={calcResult.name} size="sm" fallbackText={calcResult.symbol} />
                </div>
                <div>
                  <h4 className="font-serif text-sm font-bold text-amber-200">
                    {calcResult.name} ({calcResult.dates})
                  </h4>
                  <p className="text-[10px] text-purple-300">
                    Element: {calcResult.element} • Planetary Ruler: {calcResult.ruler}
                  </p>
                </div>
              </div>
              <div className="rounded-xl bg-amber-500/20 border border-amber-400/40 px-2.5 py-1 text-center">
                <div className="text-[9px] text-amber-300 uppercase font-bold">Chaldean Root</div>
                <div className="font-serif text-sm font-black text-amber-200">#{calcResult.chaldeanRoot}</div>
              </div>
            </div>
            <p className="text-xs text-purple-100/90 leading-relaxed">
              {calcResult.description}
            </p>
          </div>
        )}
      </div>

      {/* CARD 3: FREE 3-DAY TRIAL & MEMBERSHIP ACCESS NOTICE BANNER */}
      <div className="rounded-3xl border-2 border-amber-500/40 bg-gradient-to-r from-purple-950 via-slate-900 to-amber-950/40 p-5 sm:p-6 shadow-xl space-y-3">
        <div className="flex items-start space-x-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-amber-500/20 border border-amber-400/40 text-amber-300">
            <Gift className="h-5 w-5 animate-pulse" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="font-serif text-sm font-bold text-amber-200">
                Universal Sanctuary Access & Pricing
              </span>
              <span className="rounded-full bg-amber-500/20 px-2 py-0.5 text-[9px] font-bold text-amber-300 uppercase">
                Free 3 Days
              </span>
            </div>
            <p className="text-xs text-purple-200/90 leading-relaxed">
              You <strong>must have the free trial activated or a membership</strong> to access all features. The free app gives access to your <strong>daily horoscope</strong>, <strong>daily tarot card pull</strong>, and <strong>Life Path number calculation</strong>.
            </p>
          </div>
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-2 border-t border-purple-900/40">
          <div className="text-[11px] text-amber-300/90 font-medium">
            $3/week • $11/month • Or Only $33 for Lifetime
          </div>

          <div className="flex items-center space-x-2 w-full sm:w-auto">
            {!membership.isActive ? (
              <button
                type="button"
                onClick={() => onOpenWelcomeModal(undefined, 'letter')}
                className="flex-1 sm:flex-initial rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 px-4 py-2 text-xs font-serif font-bold text-slate-950 shadow-md hover:from-amber-300 hover:to-amber-400 transition-all"
              >
                Claim 3-Day Free Trial ($0)
              </button>
            ) : (
              <span className="text-xs font-semibold text-emerald-300 flex items-center space-x-1">
                <Check className="h-3.5 w-3.5" />
                <span>Sanctuary Unlocked</span>
              </span>
            )}

            <button
              type="button"
              onClick={() => onOpenWelcomeModal(undefined, 'plans')}
              className="rounded-xl border border-purple-700 bg-purple-950/60 px-3.5 py-2 text-xs font-semibold text-purple-200 hover:bg-purple-900/60 transition-all"
            >
              View Plans ($3, $11, $33)
            </button>
          </div>
        </div>
      </div>

      {/* CARD 4: DAILY BREADCRUMBS (1-Card Tarot Pull & Quick Modules) */}
      <div className="rounded-3xl border border-purple-900/50 bg-slate-950/80 p-6 shadow-2xl backdrop-blur-md space-y-4">
        <div className="flex items-center justify-between">
          <div className="text-[11px] font-mono font-bold tracking-widest text-purple-400 uppercase">
            DAILY TAROT CARD PULL (FREE ALWAYS)
          </div>
          <span className="text-[10px] font-mono text-purple-400">
            Resets in {timeToMidnight.hours}h {timeToMidnight.minutes}m
          </span>
        </div>

        {dailyCard ? (
          <div className="rounded-2xl border border-purple-800/60 bg-gradient-to-br from-purple-950/40 via-slate-900 to-indigo-950/40 p-4 space-y-4">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
              <div className="shrink-0">
                <TarotCardVisual
                  card={dailyCard}
                  isReversed={dailyCard.isReversed}
                  size="sm"
                  allowZoom={true}
                />
              </div>

              <div className="flex-1 space-y-2 text-center sm:text-left">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-serif text-base font-bold text-amber-200">
                      {dailyCard.name} {dailyCard.isReversed ? '(Reversed)' : '(Upright)'}
                    </h4>
                    <p className="text-xs text-purple-300/80">
                      {dailyCard.arcana} Arcana • Element: {dailyCard.element}
                    </p>
                  </div>
                  <span className="rounded-full bg-amber-400/10 border border-amber-400/30 px-2 py-0.5 text-[10px] text-amber-300 font-bold">
                    Today's Guide
                  </span>
                </div>

                <p className="text-xs text-slate-200 leading-relaxed font-sans">
                  {dailyCard.isReversed ? dailyCard.reversedMeaning : dailyCard.uprightMeaning}
                </p>
              </div>
            </div>

            {(dailyCard.pictorialKeyUpright || dailyCard.pictorialKeyReversed) && (
              <div className="rounded-xl border border-amber-500/20 bg-slate-950/70 p-2.5 text-[11px] text-amber-200/90 space-y-1">
                <span className="font-bold text-amber-400 text-[10px] uppercase tracking-wider block">
                  Pictorial Key (1911) Divinatory Insight:
                </span>
                <p className="italic text-purple-200/90 text-[11px] leading-relaxed">
                  "{dailyCard.isReversed && dailyCard.pictorialKeyReversed ? dailyCard.pictorialKeyReversed : dailyCard.pictorialKeyUpright}"
                </p>
              </div>
            )}

            <div className="rounded-xl bg-slate-950/60 p-2.5 border border-purple-900/50 text-[11px] text-amber-200/90 italic">
              ✨ Affirmation: "{dailyCard.affirmation}"
            </div>

            <div className="flex items-center justify-between pt-1">
              <button
                onClick={handleSaveToJournal}
                className="text-xs text-amber-300 hover:text-amber-200 flex items-center space-x-1"
              >
                <BookOpen className="h-3.5 w-3.5" />
                <span>{isSavedToday ? 'Saved to Journal!' : 'Save Reading to Journal'}</span>
              </button>

              <button
                onClick={() => onNavigate('tarot')}
                className="text-xs text-purple-300 hover:text-white underline"
              >
                Open Tarot Temple →
              </button>
            </div>
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-purple-800/60 p-6 text-center space-y-3">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-950/80 border border-purple-700 text-amber-300 shadow-lg shadow-purple-950/60">
              <Moon className="h-7 w-7 animate-pulse" />
            </div>
            <div className="space-y-1">
              <h4 className="font-serif text-sm font-bold text-slate-100">
                Your Daily Tarot Card Awaits
              </h4>
              <p className="text-xs text-purple-300/80 max-w-xs mx-auto">
                Draw 1 sacred Rider-Waite archetype card per day to ground your morning intuition.
              </p>
            </div>
            <button
              onClick={handlePullDailyCard}
              disabled={isFlipping}
              className="rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 px-6 py-2.5 font-mono text-xs font-bold tracking-wider text-white shadow-lg hover:from-purple-500 hover:to-indigo-500 active:scale-95 transition-all"
            >
              {isFlipping ? 'Shuffling the Deck...' : 'PULL DAILY TAROT CARD'}
            </button>
          </div>
        )}
      </div>

    </div>
  );
};
