import React from 'react';

interface ZodiacSymbolIconProps {
  sign: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  fallbackText?: string;
}

export const ZodiacSymbolIcon: React.FC<ZodiacSymbolIconProps> = ({
  sign,
  className = '',
  size = 'md',
  fallbackText,
}) => {
  const normalizedSign = sign.toLowerCase().trim();

  const sizeDimensions = {
    sm: 'h-7 w-7 text-sm',
    md: 'h-10 w-10 text-lg',
    lg: 'h-14 w-14 text-2xl',
    xl: 'h-20 w-20 text-4xl',
    '2xl': 'h-28 w-28 text-5xl',
  };

  const renderGlyph = () => {
    switch (normalizedSign) {
      case 'aries':
        return (
          /* Aries Ram Horns ♈ */
          <g>
            {/* Left Horn */}
            <path
              d="
                M 100,142
                L 100,94
                C 100,82 92,68 78,68
                C 65,68 56,76 56,89
                C 56,98 62,104 67,104
                C 71,104 74,101 74,97
                C 74,90 68,89 68,85
                C 68,79 73,74 81,74
                C 89,74 94,82 94,94
                L 94,142
                Z
              "
              fill="#ffffff"
            />
            {/* Right Horn */}
            <path
              d="
                M 100,142
                L 100,94
                C 100,82 108,68 122,68
                C 135,68 144,76 144,89
                C 144,98 138,104 133,104
                C 129,104 126,101 126,97
                C 126,90 132,89 132,85
                C 132,79 127,74 119,74
                C 111,74 106,82 106,94
                L 106,142
                Z
              "
              fill="#ffffff"
            />
            {/* Stem Bridge */}
            <path d="M 94,100 L 106,100 L 104,144 L 96,144 Z" fill="#ffffff" />
          </g>
        );

      case 'taurus':
        return (
          /* Taurus Bull ♉ */
          <g>
            <circle cx="100" cy="121" r="23.5" fill="none" stroke="#ffffff" strokeWidth="11" />
            <path
              d="
                M 59,71
                L 59,82
                C 67,83 76,90 84,101
                C 89,107 94,110 100,110
                C 106,110 111,107 116,101
                C 124,90 133,83 141,82
                L 141,71
                C 130,72 120,80 111,92
                C 107,97 104,99 100,99
                C 96,99 93,97 89,92
                C 80,80 70,72 59,71
                Z
              "
              fill="#ffffff"
            />
          </g>
        );

      case 'gemini':
        return (
          /* Gemini Twins ♊ */
          <g>
            {/* Top Arched Bar */}
            <path
              d="M 61,65 C 75,70 125,70 139,65 L 139,76 C 125,81 75,81 61,76 Z"
              fill="#ffffff"
            />
            {/* Bottom Arched Bar */}
            <path
              d="M 61,135 C 75,130 125,130 139,135 L 139,124 C 125,119 75,119 61,124 Z"
              fill="#ffffff"
            />
            {/* Left Pillar */}
            <rect x="79" y="74" width="11" height="52" fill="#ffffff" rx="1" />
            {/* Right Pillar */}
            <rect x="110" y="74" width="11" height="52" fill="#ffffff" rx="1" />
          </g>
        );

      case 'cancer':
        return (
          /* Cancer Crab Claws ♋ */
          <g>
            {/* Top Claw (6 Shape) */}
            <circle cx="75" cy="88" r="14" fill="none" stroke="#ffffff" strokeWidth="10" />
            <path
              d="M 75,74 C 95,74 136,78 136,98 L 126,98 C 126,86 95,84 75,84 Z"
              fill="#ffffff"
            />
            {/* Bottom Claw (9 Shape) */}
            <circle cx="125" cy="112" r="14" fill="none" stroke="#ffffff" strokeWidth="10" />
            <path
              d="M 125,126 C 105,126 64,122 64,102 L 74,102 C 74,114 105,116 125,116 Z"
              fill="#ffffff"
            />
          </g>
        );

      case 'leo':
        return (
          /* Leo Lion ♌ */
          <g>
            {/* Left Circle */}
            <circle cx="76" cy="118" r="14.5" fill="none" stroke="#ffffff" strokeWidth="10" />
            {/* Mane Arch and Flowing Tail */}
            <path
              d="
                M 87,110
                C 85,90 92,68 111,68
                C 128,68 135,82 135,97
                C 135,118 116,134 116,140
                C 116,145 120,147 126,147
                C 132,147 137,143 139,138
                L 146,141
                C 142,152 134,157 124,157
                C 111,157 105,149 105,138
                C 105,126 124,112 124,97
                C 124,87 119,78 111,78
                C 99,78 95,95 96,110
                Z
              "
              fill="#ffffff"
            />
          </g>
        );

      case 'virgo':
        return (
          /* Virgo Maiden ♍ */
          <g>
            {/* Three Downward Legs with top rounded loops */}
            <path
              d="
                M 63,124 L 63,94 C 63,80 71,70 82,70 C 90,70 96,75 99,83
                C 103,75 109,70 118,70 C 128,70 135,78 135,91 L 135,125
                L 125,125 L 125,92 C 125,84 121,79 115,79 C 108,79 104,85 104,93
                L 104,124 L 94,124 L 94,92 C 94,84 90,79 84,79 C 77,79 73,85 73,93
                L 73,124 Z
              "
              fill="#ffffff"
            />
            {/* Crossed Loop and Ribbon Tail */}
            <path
              d="
                M 125,108
                C 134,112 142,118 142,128
                C 142,141 129,149 116,149
                C 112,149 108,148 105,146
                L 108,137
                C 111,139 114,140 117,140
                C 124,140 132,135 132,127
                C 132,121 126,116 118,114
                L 125,108
                Z
              "
              fill="#ffffff"
            />
            {/* Crossed Tail Arrow / Slash */}
            <path
              d="M 120,120 L 146,148 L 139,155 L 113,127 Z"
              fill="#ffffff"
            />
          </g>
        );

      case 'libra':
        return (
          /* Libra Scales ♎ */
          <g>
            {/* Upper Omega Bar */}
            <path
              d="
                M 55,100
                L 74,100
                C 76,82 86,70 100,70
                C 114,70 124,82 126,100
                L 145,100
                L 145,110
                L 124,110
                C 121,98 112,80 100,80
                C 88,80 79,98 76,110
                L 55,110
                Z
              "
              fill="#ffffff"
            />
            {/* Lower Parallel Line */}
            <rect x="55" y="122" width="90" height="10.5" fill="#ffffff" rx="1" />
          </g>
        );

      case 'scorpio':
        return (
          /* Scorpio Scorpion ♏ */
          <g>
            {/* Three Downward Legs */}
            <path
              d="
                M 65,124 L 65,94 C 65,80 73,70 84,70 C 92,70 98,75 101,83
                C 105,75 111,70 120,70 C 130,70 137,78 137,91 L 137,126
                C 137,138 143,142 150,142 L 152,142 L 148,152 C 141,152 127,148 127,133
                L 127,92 C 127,84 123,79 117,79 C 110,79 106,85 106,93
                L 106,124 L 96,124 L 96,92 C 96,84 92,79 86,79 C 79,79 75,85 75,93
                L 75,124 Z
              "
              fill="#ffffff"
            />
            {/* Pointed Stinger Arrow Tip */}
            <path
              d="M 137,143 L 155,143 L 155,125 L 165,138 L 137,143 Z"
              fill="#ffffff"
            />
            <polygon points="144,147 163,147 154,128" fill="#ffffff" />
          </g>
        );

      case 'sagittarius':
        return (
          /* Sagittarius Archer ♐ */
          <g>
            {/* Arrowhead */}
            <path
              d="
                M 143,62
                L 105,62
                L 105,73
                L 125,73
                L 64,134
                L 71,141
                L 132,80
                L 132,100
                L 143,100
                Z
              "
              fill="#ffffff"
            />
            {/* Crossbar */}
            <path
              d="
                M 82,101
                L 104,123
                L 97,130
                L 75,108
                Z
              "
              fill="#ffffff"
            />
          </g>
        );

      case 'capricorn':
        return (
          /* Capricorn Sea-Goat ♑ */
          <g>
            {/* Left Horn/Leg V Shape */}
            <path
              d="
                M 56,76
                C 64,76 72,82 77,93
                L 77,126
                L 88,126
                L 88,86
                C 88,74 95,68 105,68
                C 114,68 122,76 122,88
                L 122,112
                C 127,105 133,101 141,101
                C 152,101 161,110 161,121
                C 161,133 151,143 138,143
                C 126,143 118,134 115,123
                L 105,145
                L 95,145
                L 112,108
                L 112,88
                C 112,82 108,78 103,78
                C 98,78 96,82 96,88
                L 77,142
                L 67,142
                L 67,95
                C 64,88 60,86 56,86
                Z
              "
              fill="#ffffff"
            />
            {/* Tail Loop Inner Hole */}
            <circle cx="138" cy="122" r="9" fill="none" stroke="#ffffff" strokeWidth="8" />
          </g>
        );

      case 'aquarius':
        return (
          /* Aquarius Water Waves ♒ */
          <g>
            {/* Top Zig-Zag Wave */}
            <path
              d="
                M 54,89
                L 72,71
                L 91,89
                L 109,71
                L 128,89
                L 146,71
                L 146,84
                L 128,102
                L 109,84
                L 91,102
                L 72,84
                L 54,102
                Z
              "
              fill="#ffffff"
            />
            {/* Bottom Zig-Zag Wave */}
            <path
              d="
                M 54,121
                L 72,103
                L 91,121
                L 109,103
                L 128,121
                L 146,103
                L 146,116
                L 128,134
                L 109,116
                L 91,134
                L 72,116
                L 54,134
                Z
              "
              fill="#ffffff"
            />
          </g>
        );

      case 'pisces':
        return (
          /* Pisces Two Fishes ♓ */
          <g>
            {/* Left Crescent Bar */}
            <path
              d="
                M 80,65
                C 65,77 65,123 80,135
                L 69,135
                C 53,121 53,79 69,65
                Z
              "
              fill="#ffffff"
            />
            {/* Right Crescent Bar */}
            <path
              d="
                M 120,65
                C 135,77 135,123 120,135
                L 131,135
                C 147,121 147,79 131,65
                Z
              "
              fill="#ffffff"
            />
            {/* Center Connecting Horizontal Crossbar */}
            <rect x="64" y="95" width="72" height="10" fill="#ffffff" rx="1" />
          </g>
        );

      default:
        return (
          <text
            x="100"
            y="115"
            textAnchor="middle"
            fill="#ffffff"
            fontSize="48"
            fontFamily="serif"
            fontWeight="bold"
          >
            {fallbackText || sign}
          </text>
        );
    }
  };

  return (
    <div 
      className={`relative inline-flex items-center justify-center shrink-0 select-none ${sizeDimensions[size]} ${className}`}
      title={`${sign} - Celestial Zodiac`}
    >
      <svg 
        viewBox="0 0 200 200" 
        className="h-full w-full drop-shadow-[0_0_12px_rgba(56,189,248,0.75)]"
      >
        <defs>
          {/* Outer Neon Cyan Glow Filter */}
          <filter id={`zodiacCyanGlow-${normalizedSign}`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3.5" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Inner Nebula Texture Gradient */}
          <radialGradient id={`zodiacNebulaCore-${normalizedSign}`} cx="45%" cy="40%" r="60%">
            <stop offset="0%" stopColor="#4338ca" />
            <stop offset="40%" stopColor="#2e1065" />
            <stop offset="70%" stopColor="#1e1b4b" />
            <stop offset="100%" stopColor="#090a1a" />
          </radialGradient>

          {/* Paint splash colors for texture */}
          <linearGradient id={`zodiacSplashGrad-${normalizedSign}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.8" />
            <stop offset="35%" stopColor="#3b82f6" stopOpacity="0.9" />
            <stop offset="70%" stopColor="#9333ea" stopOpacity="0.85" />
            <stop offset="100%" stopColor="#db2777" stopOpacity="0.7" />
          </linearGradient>

          <clipPath id={`zodiacCoreClip-${normalizedSign}`}>
            <circle cx="100" cy="100" r="64" />
          </clipPath>
        </defs>

        {/* Scalloped Wavy Neon Cyan Outer Rosette Border */}
        <path
          d="
            M 100,8
            C 112,8 119,16 130,20
            C 141,24 153,24 162,32
            C 171,40 172,52 178,63
            C 184,74 192,81 192,93
            C 192,106 184,113 178,124
            C 172,135 171,147 162,155
            C 153,163 141,163 130,167
            C 119,171 112,179 100,179
            C 88,179 81,171 70,167
            C 59,163 47,163 38,155
            C 29,147 28,135 22,124
            C 16,113 8,106 8,93
            C 8,81 16,74 22,63
            C 28,52 29,40 38,32
            C 47,24 59,24 70,20
            C 81,16 88,8 100,8
            Z
          "
          fill="#030712"
          stroke="#38bdf8"
          strokeWidth="5"
          strokeLinejoin="round"
          filter={`url(#zodiacCyanGlow-${normalizedSign})`}
        />

        {/* Concentric Ribbed Mid-Ring */}
        <circle
          cx="100"
          cy="100"
          r="75"
          fill="none"
          stroke="#0284c7"
          strokeWidth="3.5"
          strokeDasharray="2 2"
          opacity="0.8"
        />

        {/* Inner Glowing Cyan Circular Rim */}
        <circle
          cx="100"
          cy="100"
          r="67"
          fill="none"
          stroke="#7dd3fc"
          strokeWidth="4"
          filter={`url(#zodiacCyanGlow-${normalizedSign})`}
        />

        {/* Nebula / Cosmic Textured Core Background */}
        <g clipPath={`url(#zodiacCoreClip-${normalizedSign})`}>
          <circle cx="100" cy="100" r="64" fill={`url(#zodiacNebulaCore-${normalizedSign})`} />
          
          {/* Painted Nebula Streaks across core */}
          <path
            d="M35,60 Q80,120 120,40 Q150,90 165,130 L165,165 L35,165 Z"
            fill={`url(#zodiacSplashGrad-${normalizedSign})`}
            opacity="0.85"
          />
          <path
            d="M40,140 Q90,70 140,110 Q160,130 165,150 L100,165 Z"
            fill="#c026d3"
            opacity="0.45"
          />
          <circle cx="70" cy="80" r="30" fill="#0284c7" opacity="0.4" />
          <circle cx="130" cy="120" r="35" fill="#ec4899" opacity="0.35" />
          <circle cx="95" cy="115" r="25" fill="#38bdf8" opacity="0.3" />
        </g>

        {/* GLYPH LAYER */}
        <g filter={`url(#zodiacCyanGlow-${normalizedSign})`}>
          {renderGlyph()}
        </g>

      </svg>
    </div>
  );
};
