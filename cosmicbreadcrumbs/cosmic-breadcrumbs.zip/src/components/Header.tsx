import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Moon, 
  Compass, 
  Hash, 
  Feather, 
  BookOpen, 
  MessageSquareQuote, 
  User, 
  Share2,
  Sliders,
  Lock,
  CloudMoon,
  BookMarked,
  Gift,
  Crown,
  CheckCircle2
} from 'lucide-react';
import { CosmicView, UserProfile, MembershipStatus } from '../types';
import { getMoonPhaseInfo } from '../utils/astrologyCalc';
import { getTrialTimeRemaining, isFeatureUnlocked } from '../utils/membership';

import { CosmicLogo } from './CosmicLogo';

interface HeaderProps {
  currentView: CosmicView;
  onViewChange: (view: CosmicView) => void;
  userProfile: UserProfile;
  onOpenProfile: () => void;
  onOpenOracleChat: () => void;
  membership: MembershipStatus;
  onOpenMembership: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onViewChange,
  userProfile,
  onOpenProfile,
  onOpenOracleChat,
  membership,
  onOpenMembership,
}) => {
  const [moonInfo] = useState(() => getMoonPhaseInfo());
  const [copiedShare, setCopiedShare] = useState(false);

  const trialTime = getTrialTimeRemaining(membership.trialExpiryDate);

  const handleShareApp = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Cosmic Breadcrumbs - Universal Insights',
          text: `Your daily guide to universal insights—designed to awaken your third eye, expand awareness, and unlock your intuitive power. The universe is always leaving trails of wisdom—follow the breadcrumbs and explore the depths of your true potential.`,
          url: window.location.href,
        });
      } catch (err) {}
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    }
  };

  const navItems: { id: CosmicView; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'dashboard', label: 'Cosmic Hub', icon: Sparkles },
    { id: 'horoscope', label: 'Horoscope', icon: Compass },
    { id: 'tarot', label: 'Daily Tarot', icon: Moon },
    { id: 'numerology', label: 'Numerology', icon: Hash },
    { id: 'angel-oracle', label: 'Archangels', icon: Feather },
    { id: 'dreams', label: 'Dream Sanctuary', icon: CloudMoon },
    { id: 'diary', label: 'Daily Log/Journal', icon: BookMarked },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-purple-900/40 bg-slate-950/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Logo & Brand */}
        <div 
          onClick={() => onViewChange('dashboard')}
          className="group flex cursor-pointer items-center space-x-2.5 sm:space-x-3"
          id="app-brand-logo"
        >
          <CosmicLogo size="md" showUploadTrigger={true} />
          <div className="flex flex-col text-left">
            <span className="font-flavors text-lg sm:text-xl md:text-2xl text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-rose-200 to-purple-200 tracking-wide drop-shadow-sm leading-none py-0.5">
              Cosmic Breadcrumbs
            </span>
            <span className="text-[9px] font-mono tracking-wider text-purple-300/70 hidden sm:block mt-0.5">
              YOUR PERSONALIZED COSMIC ALIGNMENT
            </span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden xl:flex items-center space-x-1.5 rounded-2xl border border-purple-700/60 bg-slate-900/90 p-1.5 shadow-lg shadow-purple-950/40 backdrop-blur-md">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            const isUnlocked = isFeatureUnlocked(item.id, membership);

            return (
              <button
                key={item.id}
                id={`nav-link-${item.id}`}
                onClick={() => onViewChange(item.id)}
                className={`flex items-center space-x-2 rounded-xl px-3.5 py-2 text-[13px] font-bold tracking-wide transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-purple-600 via-purple-700 to-indigo-600 text-white shadow-md shadow-purple-600/40 border border-amber-400/60 ring-1 ring-amber-400/30'
                    : 'text-purple-100 hover:bg-purple-900/60 hover:text-white border border-transparent hover:border-purple-600/40'
                }`}
              >
                <Icon className={`h-4 w-4 ${isActive ? 'text-amber-300' : 'text-purple-300'}`} />
                <span>{item.label}</span>
                {!isUnlocked && (
                  <Lock className="h-3 w-3 text-amber-400" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Medium Screen Navigation (lg to xl) */}
        <nav className="hidden lg:flex xl:hidden items-center space-x-1 rounded-xl border border-purple-700/60 bg-slate-900/90 p-1 shadow-md">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            const isUnlocked = isFeatureUnlocked(item.id, membership);

            return (
              <button
                key={item.id}
                id={`nav-link-med-${item.id}`}
                onClick={() => onViewChange(item.id)}
                className={`flex items-center space-x-1.5 rounded-lg px-2.5 py-1.5 text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-purple-600 text-white border border-amber-400/60 shadow-sm'
                    : 'text-purple-100 hover:bg-purple-900/60 hover:text-white'
                }`}
              >
                <Icon className={`h-3.5 w-3.5 ${isActive ? 'text-amber-300' : 'text-purple-300'}`} />
                <span>{item.label}</span>
                {!isUnlocked && (
                  <Lock className="h-2.5 w-2.5 text-amber-400" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Controls */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          
          {/* Membership / Trial Status Pill Button */}
          <button
            id="btn-header-membership"
            onClick={onOpenMembership}
            className={`flex items-center space-x-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-all shadow-sm ${
              membership.tier === 'trial' && membership.isActive
                ? 'border border-amber-400/60 bg-gradient-to-r from-amber-500/20 to-purple-600/20 text-amber-200 hover:border-amber-300 animate-pulse'
                : membership.tier !== 'free' && membership.isActive
                ? 'border border-amber-500/50 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20'
                : 'border border-purple-500/50 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 hover:from-amber-400 hover:to-amber-500 font-serif font-bold shadow-amber-500/20'
            }`}
            title="View 3-Day Free Trial & Subscription Options ($3, $11, $33)"
          >
            {membership.tier === 'trial' && membership.isActive ? (
              <>
                <Gift className="h-3.5 w-3.5 text-amber-400" />
                <span>Free Trial ({trialTime.days}d {trialTime.hours}h)</span>
              </>
            ) : membership.tier !== 'free' && membership.isActive ? (
              <>
                <Crown className="h-3.5 w-3.5 text-amber-400" />
                <span>{membership.tier === 'lifetime' ? 'Lifetime VIP' : 'Member'}</span>
              </>
            ) : (
              <>
                <Gift className="h-3.5 w-3.5 text-slate-950" />
                <span>3-Day Free Trial</span>
              </>
            )}
          </button>

          {/* Ask Oracle Button */}
          <button
            id="btn-ask-oracle"
            onClick={onOpenOracleChat}
            className="flex items-center space-x-1.5 rounded-full border border-purple-500/50 bg-gradient-to-r from-purple-900/60 to-indigo-900/60 px-3 py-1.5 text-xs font-medium text-purple-100 hover:border-purple-400 hover:from-purple-800/80 hover:to-indigo-800/80 transition-all shadow-sm"
          >
            <MessageSquareQuote className="h-3.5 w-3.5 text-amber-300" />
            <span className="hidden sm:inline">Ask Oracle</span>
            {!membership.isActive && <Lock className="h-2.5 w-2.5 text-amber-400/80" />}
          </button>

          {/* Share */}
          <button
            id="btn-share-app"
            onClick={handleShareApp}
            title="Share Sanctuary"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-purple-800/60 bg-slate-900/80 text-purple-300 hover:bg-purple-900/40 transition-all"
          >
            <Share2 className="h-4 w-4" />
          </button>

          {/* User Profile */}
          <button
            id="btn-open-profile"
            onClick={onOpenProfile}
            className="flex items-center space-x-1.5 rounded-full border border-amber-500/40 bg-gradient-to-r from-amber-500/10 to-purple-500/10 px-2.5 py-1 text-xs text-amber-200 hover:border-amber-400 transition-all"
          >
            <div className="flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-purple-600 text-slate-950 font-bold text-[10px]">
              {userProfile.name ? userProfile.name.charAt(0).toUpperCase() : 'S'}
            </div>
            <span className="font-medium max-w-[80px] truncate hidden sm:inline">
              {userProfile.name || 'Seeker'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="flex lg:hidden overflow-x-auto no-scrollbar border-t border-purple-900/50 bg-slate-950/95 px-3 py-2.5 space-x-1.5 shadow-inner">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          const isUnlocked = isFeatureUnlocked(item.id, membership);

          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`flex shrink-0 items-center space-x-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border border-amber-400/60 shadow-md ring-1 ring-amber-400/30'
                  : 'bg-slate-900/90 text-purple-100 border border-purple-800/60 hover:border-purple-600 hover:text-white'
              }`}
            >
              <Icon className={`h-3.5 w-3.5 ${isActive ? 'text-amber-300' : 'text-purple-300'}`} />
              <span>{item.label}</span>
              {!isUnlocked && (
                <Lock className="h-2.5 w-2.5 text-amber-400" />
              )}
            </button>
          );
        })}
      </div>
    </header>
  );
};

